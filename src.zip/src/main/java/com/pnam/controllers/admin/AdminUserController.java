package com.pnam.controllers.admin;

import com.pnam.pojo.User;
import com.pnam.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/admin/users")
public class AdminUserController {

    @Autowired
    private UserService userService;

    // Danh sách user
    @GetMapping
    public String list(Model model) {
        List<User> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "admin/users/list";
    }

    // Chi tiết user
    @GetMapping("/{id}")
    public String detail(@PathVariable("id") Long id, Model model) {
        User user = userService.getUserById(id);
        model.addAttribute("user", user);
        return "admin/users/detail";
    }

    // Form tạo mới user
    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("user", new User());
        return "admin/users/form";
    }

    // Form chỉnh sửa user
    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable("id") Long id, Model model) {
        User user = userService.getUserById(id);
        model.addAttribute("user", user);
        return "admin/users/form";
    }

    @PostMapping(path = "/save", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public String save(@ModelAttribute("user") User user,
            @RequestParam(value = "avatarFile", required = false) MultipartFile avatarFile) {
        try {
            // Nếu có upload avatar thì upload lên Cloudinary
            if (avatarFile != null && !avatarFile.isEmpty()) {
                String url = userService.uploadAvatar(avatarFile);
                user.setAvatarUrl(url);
            }

            if (user.getId() == null) {
                // Tạo mới
                userService.register(user);
            } else {
                // Cập nhật
                userService.updateUser(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "redirect:/admin/users";
    }

    // Khóa user
    @GetMapping("/lock/{id}")
    public String lock(@PathVariable("id") Long id) {
        userService.lockUser(id);
        return "redirect:/admin/users";
    }

    // Mở khóa user
    @GetMapping("/unlock/{id}")
    public String unlock(@PathVariable("id") Long id) {
        userService.unlockUser(id);
        return "redirect:/admin/users";
    }

    // Xóa user
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable("id") Long id) {
        userService.deleteUser(id);
        return "redirect:/admin/users";
    }
}
