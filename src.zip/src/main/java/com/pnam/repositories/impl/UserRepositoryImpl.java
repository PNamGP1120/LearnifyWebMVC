package com.pnam.repositories.impl;

import com.pnam.pojo.User;
import com.pnam.repositories.UserRepository;
import jakarta.persistence.NoResultException;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class UserRepositoryImpl implements UserRepository {

    @Autowired
    private LocalSessionFactoryBean sessionFactory;

    @Override
    public User getUserByUsername(String username) {
        Session s = sessionFactory.getObject().getCurrentSession();
        Query q = s.createQuery("FROM User WHERE username = :un");
        q.setParameter("un", username);
        try {
            return (User) q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public User getUserByEmail(String email) {
        Session s = sessionFactory.getObject().getCurrentSession();
        Query q = s.createQuery("FROM User WHERE email = :em");
        q.setParameter("em", email);
        try {
            return (User) q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public void addUser(User user) {
        Session s = sessionFactory.getObject().getCurrentSession();
        s.persist(user);
    }

    @Override
    public void updateUser(User user) {
        Session s = sessionFactory.getObject().getCurrentSession();
        s.merge(user);
    }

    @Override
    public void deleteUser(Long id) {
        Session s = sessionFactory.getObject().getCurrentSession();
        User u = s.get(User.class, id);
        if (u != null) {
            s.remove(u);
        }
    }

    @Override
    public User getUserById(Long id) {
        Session s = sessionFactory.getObject().getCurrentSession();
        return s.find(User.class, id);
    }

    @Override
    public List<User> getAllUsers() {
        Session s = sessionFactory.getObject().getCurrentSession();
        Query<User> q = s.createQuery("FROM User", User.class);
        return q.getResultList();
    }

}
