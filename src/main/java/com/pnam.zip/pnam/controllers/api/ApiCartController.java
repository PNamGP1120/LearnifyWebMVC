package com.pnam.controllers.api;

import com.pnam.pojo.Cart;
import com.pnam.pojo.CartItem;
import com.pnam.services.CartService;
import com.pnam.services.CartItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin
public class ApiCartController {

    @Autowired
    private CartService cartService;
    @Autowired
    private CartItemService cartItemService;

    // Lấy giỏ hàng theo student
    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<Cart>> getByStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(cartService.getCartsByStudent(studentId));
    }

    // Lấy chi tiết giỏ hàng
    @GetMapping("/{id}")
    public ResponseEntity<Cart> getCart(@PathVariable Long id) {
        Cart c = cartService.getCartById(id);
        return c != null ? ResponseEntity.ok(c) : ResponseEntity.notFound().build();
    }

    // Tạo giỏ hàng mới
    @PostMapping
    public ResponseEntity<Cart> create(@RequestBody Cart c) {
        return ResponseEntity.ok(cartService.createCart(c));
    }

    // Update giỏ hàng
    @PutMapping("/{id}")
    public ResponseEntity<Cart> update(@PathVariable Long id, @RequestBody Cart c) {
        c.setId(id);
        return ResponseEntity.ok(cartService.updateCart(c));
    }

    // Xoá giỏ hàng
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        cartService.deleteCart(id);
        return ResponseEntity.noContent().build();
    }

    // Lấy danh sách item trong giỏ
    @GetMapping("/{cartId}/items")
    public ResponseEntity<List<CartItem>> items(@PathVariable Long cartId) {
        return ResponseEntity.ok(cartItemService.getCartItemsByCart(cartId));
    }

    // Thêm item
    @PostMapping("/{cartId}/items")
    public ResponseEntity<CartItem> addItem(@PathVariable Long cartId, @RequestBody CartItem ci) {
        ci.setCartId(cartService.getCartById(cartId)); // truyền object Cart
        return ResponseEntity.ok(cartItemService.createCartItem(ci));
    }

    // Update item
    @PutMapping("/items/{id}")
    public ResponseEntity<CartItem> updateItem(@PathVariable Long id, @RequestBody CartItem ci) {
        ci.setId(id);
        return ResponseEntity.ok(cartItemService.updateCartItem(ci));
    }

    // Xoá item
    @DeleteMapping("/items/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable Long id) {
        cartItemService.deleteCartItem(id);
        return ResponseEntity.noContent().build();
    }
}
