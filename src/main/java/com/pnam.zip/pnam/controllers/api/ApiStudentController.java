package com.pnam.controllers.api;

import com.pnam.pojo.Enrollment;
import com.pnam.services.EnrollmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/student")
@CrossOrigin
public class ApiStudentController {

    @Autowired
    private EnrollmentService enrollmentService;

    @GetMapping("/enrollments")
    public ResponseEntity<List<Enrollment>> list(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(enrollmentService.getEnrollments(params));
    }

    @PostMapping("/enrollments")
    public ResponseEntity<Enrollment> create(@RequestBody Enrollment e) {
        enrollmentService.createEnrollment(e);
        return ResponseEntity.ok(e);
    }
}
