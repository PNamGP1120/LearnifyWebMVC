package com.pnam.controllers.api;

import com.pnam.pojo.Payment;
import com.pnam.services.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin
public class ApiPaymentController {

    @Autowired
    private PaymentService paymentService;

    @GetMapping
    public ResponseEntity<List<Payment>> list(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(paymentService.getPayments(params));
    }

    @PostMapping
    public ResponseEntity<Payment> create(@RequestBody Payment p) {
        paymentService.savePayment(p);
        return ResponseEntity.ok(p);
    }
}
