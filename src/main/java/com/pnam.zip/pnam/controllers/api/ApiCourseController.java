package com.pnam.controllers.api;

import com.pnam.pojo.Course;
import com.pnam.services.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/courses")
@CrossOrigin
public class ApiCourseController {

    @Autowired
    private CourseService courseService;

    @GetMapping
    public ResponseEntity<List<Course>> list(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(courseService.getCourses(params));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Course> get(@PathVariable("id") Long id) {
        return ResponseEntity.ok(courseService.getCourseById(id));
    }
}
