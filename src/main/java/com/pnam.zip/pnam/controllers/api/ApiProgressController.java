package com.pnam.controllers.api;

import com.pnam.pojo.Progress;
import com.pnam.services.ProgressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/progress")
@CrossOrigin
public class ApiProgressController {

    @Autowired
    private ProgressService progressService;

    @GetMapping("/{id}")
    public ResponseEntity<Progress> getById(@PathVariable Long id) {
        Progress p = progressService.getProgressById(id);
        return p != null ? ResponseEntity.ok(p) : ResponseEntity.notFound().build();
    }

    @GetMapping("/enrollment/{enrollmentId}")
    public ResponseEntity<List<Progress>> getByEnrollment(@PathVariable Long enrollmentId) {
        return ResponseEntity.ok(progressService.getProgressByEnrollment(enrollmentId));
    }

    @PostMapping
    public ResponseEntity<Progress> create(@RequestBody Progress p) {
        return ResponseEntity.ok(progressService.createProgress(p));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Progress> update(@PathVariable Long id, @RequestBody Progress p) {
        p.setId(id);
        return ResponseEntity.ok(progressService.updateProgress(p));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        progressService.deleteProgress(id);
        return ResponseEntity.noContent().build();
    }
}
