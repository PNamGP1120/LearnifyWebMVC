package com.pnam.controllers.api;

import com.pnam.pojo.Course;
import com.pnam.services.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/instructor")
@CrossOrigin
public class ApiInstructorController {

    @Autowired
    private CourseService courseService;

    @PostMapping("/courses")
    public ResponseEntity<Course> create(@RequestBody Course c) {
        courseService.saveCourse(c);
        return ResponseEntity.status(HttpStatus.CREATED).body(c);
    }

    @PutMapping("/courses/{id}")
    public ResponseEntity<Course> update(@PathVariable Long id, @RequestBody Course c) {
        c.setId(id);
        courseService.saveCourse(c);
        return ResponseEntity.ok(c);
    }

    @DeleteMapping("/courses/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return ResponseEntity.noContent().build();
    }
}
