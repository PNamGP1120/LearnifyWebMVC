package com.pnam.controllers.api;

import com.pnam.pojo.CourseRating;
import com.pnam.services.CourseRatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ratings")
@CrossOrigin
public class ApiRatingController {

    @Autowired
    private CourseRatingService ratingService;

    @GetMapping
    public ResponseEntity<List<CourseRating>> list(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(ratingService.getRatings(params));
    }

    @PostMapping
    public ResponseEntity<CourseRating> create(@RequestBody CourseRating r) {
        ratingService.saveRating(r);
        return ResponseEntity.ok(r);
    }
}
